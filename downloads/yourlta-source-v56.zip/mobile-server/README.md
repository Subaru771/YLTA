# YourLTA Mobile PSN Import Server (beta)

This Node.js server is separate from the static Cloudflare Pages frontend. Deploy it on a Node.js host that supports long-running HTTP requests, such as Render (Web Service). Set build command `npm install`, start command `npm start`, and environment variable `YLTA_ORIGIN=https://yourlta.pages.dev`. Host must provide HTTPS. Test `https://YOUR-SERVER/health` first. In YourLTA's Import / Export page, enter the server's HTTPS base URL.

Security: NPSSO is a sensitive bearer credential. Only deploy to an account/server you trust; use HTTPS, restrict access and disable request-body logging. This prototype does not persist tokens and does not guarantee Sony API availability. This server is NOT suitable as a public multi-user production service without authentication, abuse controls, rate limiting, and stronger isolation. Large accounts may time out depending on host limits. Sony authentication can change without notice.
