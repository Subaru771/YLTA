---
name: Feature request
about: Suggest an improvement for trophy hunters
---

## What are you trying to do?

## What would help?

## Current workaround

## Why would you use this?
