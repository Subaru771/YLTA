---
name: Bug report
about: Report something that did not work
---

## What happened?

## Steps to reproduce
1.
2.
3.

## Expected behavior

## Device and browser

## Import method, if relevant
Phone/web, Windows exporter, existing JSON, CSV or optional PSNProfiles data?

## Error wording / screenshots
Remove NPSSO, passwords and private account information. Do not upload a full export without reviewing it. For security vulnerabilities, follow SECURITY.md instead.
